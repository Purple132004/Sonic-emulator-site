function creaCard (){
    //creo array
    let card = [
        //creo oggetti dentro array
        {
            cardDiv: "div",
            cardClass: "card  p-3 mb-5 bg-body-tertiar shadow-leo ",
            imgCard:"img",
            imgSrc:"img/sonic.png",
            imgClass:"card-img-top",
            imgAlt:"gotta go fast",
            bodyCard: "div",
            bodyClass:"card-body",
            pCard:"p",
            pClass:"card-title fs-4",
            pTitolo:"Sonic",    
            pClassTesto:"card-text fs-5",
            pText:"The Hedgehog",
            aCard:"a",
            aHref:"#",
            aClass:"btn btn-primary",
            aText:"Gotta go fast"
        },

        {
            cardDiv: "div",
            cardClass: "card  p-3 mb-5 bg-body-tertiar shadow-amy ",
            imgCard:"img",
            imgSrc:"img/amy.png",
            imgClass:"card-img-top",
            imgAlt:"gotta go fast",
            bodyCard: "div",
            bodyClass:"card-body",
            pCard:"p",
            pClass:"card-title fs-4",
            pTitolo:"Amy",    
            pClassTesto:"card-text fs-5",
            pText:"Rose",
            aCard:"a",
            aHref:"#",
            aClass:"btn bottone-amy",
            aText:"Gotta go fast"
        },

        {
            cardDiv: "div",
            cardClass: "card  p-3 mb-5 bg-body-tertiar shadow-knu ",
            imgCard:"img",
            imgSrc:"img/knucles.png",
            imgClass:"card-img-top",
            imgAlt:"gotta go fast",
            bodyCard: "div",
            bodyClass:"card-body",
            pCard:"p",
            pClass:"card-title fs-4",
            pTitolo:"Knucles",    
            pClassTesto:"card-text fs-5",
            pText:"The Echidna",
            aCard:"a",
            aHref:"#",
            aClass:"btn btn-danger",
            aText:"Gotta go fast"
        },

        {
            cardDiv: "div",
            cardClass: "card  p-3 mb-5 bg-body-tertiar shadow-tails ",
            imgCard:"img",
            imgSrc:"img/tails.png",
            imgClass:"card-img-top",
            imgAlt:"gotta go fast",
            bodyCard: "div",
            bodyClass:"card-body",
            pCard:"p",
            pClass:"card-title fs-4",
            pTitolo:"Tails",    
            pClassTesto:"card-text fs-5",
            pText:"Miles Prowler",
            aCard:"a",
            aHref:"#",
            aClass:"btn btn-warning",
            aText:"Gotta go fast"
        }

    ];

    //creo la row 
    let row = document.querySelector("#row")
    row.className = "row mt-4 d-flex justify-content-center";
    
    //creo il div per stampare l immagine
    for(let obj of card){
        let divTag = document.createElement("div");
        row.append(divTag);
        //dimensioni del div
        divTag.className = "col-2";
        let divCard = document.createElement(obj.cardDiv);
        divTag.append(divCard);
        divCard.className = obj.cardClass;
        let imgTag = document.createElement(obj.imgCard);
        divCard.append(imgTag);
        //metto gli attributi
        imgTag.src = obj.imgSrc;
        imgTag.className = obj.imgClass;
        imgTag.alt = obj.imgAlt;

        //preparo il div per scrivere titolo,sottotitolo e bottone
        let bodyTag = document.createElement(obj.bodyCard);
        //stampo tutto dopo l'img
        imgTag.after(bodyTag);


        bodyTag.classList = obj.bodyClass;

        //ptag per stampare il titolo(pTitolo)
        let pTag = document.createElement(obj.pCard);
        bodyTag.append(pTag);
        //attributi del sottotitolo,gli attributi li prendo citando obj e scegliendo poi dall'oggetto dentro l array
        pTag.className = obj.pClass;
        pTag.textContent = obj.pTitolo;

        //creo il tag "p"
        pTag = document.createElement(obj.pCard);
        //attributi del tag "p",gli attributi li prendo citando obj e scegliendo poi dall'oggetto dentro l array
        bodyTag.append(pTag);
        pTag.classList = obj.pClassTesto;
        pTag.textContent = obj.pText;

        //sezione bottone
        let aTag = document.createElement(obj.aCard);
        bodyTag.append(aTag);
        //attributi bottone,gli attributi li prendo citando obj e scegliendo poi dall'oggetto dentro l array
        aTag.href = obj.aHref;
        aTag.className = obj.aClass;
        aTag.textContent = obj.aText;
    
    }

    
    


}



document.addEventListener("DOMContentLoaded",creaCard)



/* function ValidaBtn() {
    let btn = document.querySelector("#btn #btn-id");
    let erroreVideo = document.querySelector ("#video iframe");
    if (erroreVideo != null) {
        erroreVideo.remove();
    }
    
        console.log("dati inseriti");
        let video = document.createElement("iframe");
        video.src = "https://www.youtube.com/embed/_WZCvQ5J3pk?si=c8zdkioKxQbtvFAl";
        video.width = "960";
        video.height = "560";
        video.classList.add("video");
        videoBox = document.querySelector("#video");
        videoBox.append(video);
}

aTag.addEventListener("click",ValidaBtn); */