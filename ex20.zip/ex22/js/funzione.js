function backtop(){
    
   /*  console.log(window.scrollY); */

    let back = document.querySelector("#back");
    let header = document.querySelector("#header");
    if(window.scrollY > 200){
        back.classList.add("back-show");
    }
    else{
        back.classList.remove("back-show");
    }

    if(window.scrollY > 300){
        header.classList.add("paperino");
        header.classList.remove("pippo");
    }
    else{
        header.classList.remove("paperino");
        header.classList.add("pippo");

    }
    
}

window.addEventListener('scroll',backtop);


let btn = document.querySelector("#back button");

function up(){
   /*  window.scrollTo(0,0); */

   window.scrollTo({
    top:0,
    left:0,
    behavior:"smooth"
   })

}

btn.addEventListener("click",up);